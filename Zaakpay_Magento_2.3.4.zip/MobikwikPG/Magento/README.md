Mobikwik Module for Magento
==========================

Instructions:
=============

[] Fill up Mobikwik integration form
  - Login to your Mobikwik Account and Go to My Account > Integration
  - For Transact API Return Url, enter the following url
    <http://youtstorehomeurl.com>/mobikwikpg/checkout/response
  - Enter other details, generate key and press save

[] Adding module files to your magento installation
  - Please take a backup of your code for safety.
  - Create a directory named 'code', if not  already created.
  - Copy the MobikwikPG folder in the 'code' directory.
  - run the following commands.
    - php bin/magento setup:upgrade
    - php bin/magento setup:static-content:deploy 

[] Changes for going Live.
  - Insert your merchant Identifier and secret key for live in Stores->configrations->sales->payment Methods-> Mobikwik web checkout
  - Replace the Live URl in file app->code->MobikwikPG->Magento->Model->Transact.php in the fucntion "getZaakpayTransactAction()"
    and change the URL to "https://api.Mobikwik.com/api/paymentTransact/V8"  from "https://zaakstaging.zaakpay.com/api/paymentTransact/V8"and save it. 
  - Please test for live changes with some sample products.

   PLEASE RELY ON Mobikwik PANEL FOR ACCURATE STATUS FOR ANY TRANSACTION.

[] Enabling the module and configuring it with your Mobikwik merchant credentials
  - Login to your magento admin and go to Store > Configuration.
  - On the left side bar, scroll down and click on "Payment Method" under the Sales section.
  - Scroll down the page and "Enable" the Mobikwik module.
  - On the same page, click on "Payment Methods" on the sidebar under the section "SALES".
  - On this page, a "Mobikwik Webpay checkout" section will appear. Click on it if its not already open.
  - Add your Merchant Id, secret key here. Also specify sandbox to "NO" Always. 
    click "Save Config".
    Additionally, if you want that only buyers from particular country or countries should be able to use Mobikwik,  
    against the "Payment Applicable From" field, select "Specific Countries" and then select the countries in the box
    that opens up. In order to select more than one country, you will need to click on the countries with ctrl key of the 
    keyboard pressed. Sort Order field determines in which order Mobikwik will be displayed to the buyer during checkout.
   
[] Testing Mobikwik 
  - Make sure that sandbox mode is on and all details are entered in the Mobikwik configuration
  - Go to your store and place an order. 
  - If you configured Mobikwik correctly in the previous step, it should appear as an option under payment methods
    during checkout
  - When you click on checkout, it should redirect you to Mobikwik's site and show credit card form. 
  - Use a test card from below to complete a fake payment 
  
[] Test Cards
   Type        CARD NO               CVV     EXPIRY      Month
   VISA        4000000000000002      123      2022        12
  
[] Checking the status of payment transaction at Mobikwik's end from your magento admin
  - Login to admin and under Sales, click on Orders
  - Click on the first order in the data grid. This should be the order that you just placed
  - When the order details page opens up, look for "Payment Information" block. 
    Inside the block, you can see the latest status of the transaction on Mobikwik's end. 


